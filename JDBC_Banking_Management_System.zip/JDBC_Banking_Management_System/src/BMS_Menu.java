import java.util.Scanner;

import com.demo.delete.deleteCustomer;
import com.demo.deposit.DepositFund;
import com.demo.display.displayCustomer;
import com.demo.displayOne.displayOneCustomer;
import com.demo.insert.*;
import com.demo.transfer.TransferFund;
import com.demo.update.updateCustomer;
import com.demo.withdraw.WithdrawFund;



public class BMS_Menu {

	public static void main(String[] args) {
		 
		
		Scanner sc = new Scanner(System.in);
			int choice = -1;

		      
			
		    while(choice !=0)
		    {        
		    	System.out.println("\n\n****************************************************************");
		        System.out.println("\n# Banking Management System #");
		        System.out.println("\n 1> Add Customer Record");
		        System.out.println("\n2> Get All Customer Records");
		        System.out.println("\n3> Update Customer Record");
		        System.out.println("\n4> Delete Customer Record");
		        System.out.println("\n5> Get Any Customer Record");
		        System.out.println("\n6> Deposit/Withdraw/Transfer Fund");
		        System.out.println("\n0> Exit..");
		    	System.out.println("****************************************************************\n");
		    	
		        System.out.print("\n Enter your choice : ");
		        System.out.println();
		       
			        if(sc.hasNextInt()) 
			        {
			        	
			        choice = sc.nextInt();
			        sc.nextLine();
			         //check if user inputs string instead of int
			        
			        switch(choice)
			        {
			                case 1:
			                
			                	insertCustomer.insertCustomerDetails();
			                    break;
			                    
			                case 2:
			                	
			                    displayCustomer.displayCustomerDetails();
			                    
			                    break;
			            
			                case 3: 
			                    //UPDATE CUSTOMER RECORD
			                	updateCustomer.updateCustomerDetails();            
			                    break;
			                
			               
			                case 4:
			                    //DELETE CUSTOMER RECORD
			                    deleteCustomer.deleteCustomerDetails();
			                    break;
			                    
			                case 5: 
			                    //Display One customer record;
			                	displayOneCustomer.displayAnyCustomerDetails();
			                    break;
			                    
			                
			                case 6: 
			                    //
			                		int choice2 = -1;
			                		
			                		 
				                	while(choice2 != 0)
				                	{
				                		System.out.println("****************************************************************");
				                		System.out.println("\n# Banking Management System #");
				                		System.out.println("\n 1> Deposit Funds ");
				        		        System.out.println("\n2> Withdraw funds");
				        		        System.out.println("\n3> Transfer Funds");
				        		        
				        		        System.out.println("\n0> Exit..");
				        		        System.out.println("****************************************************************\n");
				        		        System.out.print("\n Enter your choice : ");
				        		      
					        		        if(sc.hasNextInt()) {
					                		choice2 = sc.nextInt();	
					                		
						                	switch(choice2)
						    		        {
						    		                case 1:
						    		                	//Deposit Funds
						    		                	DepositFund.depositFunds();
						    		                    break;
						    		                    
						    		                case 2:
						    		                	//Withdraw Funds
						    		                    WithdrawFund.withdrawFunds();
						    		                    break;
						    		                    
						    		                case 3: 
						    		                	//Transfer Funds
						    		                	TransferFund.TransferFunds();            
						    		                    break;
						    		                
						    		               
						    		                 case 0:
						    		            	System.out.println("\n****************  Thankyou !! Good Bye  **************** \n "); 
						    		                break;
						    		                
						    		                default: 
						    		                	System.out.println("\n****************  Invalid choice  ****************\n"); 
						    		                    
						    		        }
					        		     }
					        		     else
					        		     {
					        		        	System.out.println("**********  Please Ente a valid Input  **********************");
					    			        	sc.nextLine();
					        		     }
					        		        
				                	}
				                	break;
				                
				                case 0:
				            	System.out.println("\n****************  Thankyou !! Good Bye  ****************\n "); 
				                break;
				                
				                default: 
				                	System.out.println("\n****************  Invalid choice  ****************\n"); 
				                    
				          }
			        }
			        else 
			        {
			        	System.out.println("**********  Please Ente a valid Input  **********************");
			        	sc.nextLine();
			        }
		    }
			


	}

}
