package com.demo.displayOne;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class displayOneCustomer {


	
	   static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	   static final String USER = "root";
	   static final String PASS = "";
	   static final String QUERY = "SELECT * from account where account_no = ?";

		public static void displayAnyCustomerDetails() {
			// TODO Auto-generated method stub
	
			
	try {
				Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				
			
				PreparedStatement stmt = conn.prepareStatement(QUERY);
				
				 Scanner sc = new Scanner(System.in);
				System.out.println("Enter the Customer account number: ");
				 int accno = sc.nextInt();
					
				stmt.setInt(1,accno);	
				ResultSet rs = stmt.executeQuery();
	         // Extract data from result set
	           
				
				 if (rs.next()) {
	            // Retrieve by column name
					
					 System.out.println("+-----------------+--------------------+------------------+");
					 System.out.println("| Account Number  | Customer Name      | Balance (INR)    |");
					 System.out.println("+-----------------+--------------------+------------------+");
					 System.out.printf("|  %-13s  | %-17s  | %-15s  |\n", rs.getInt("account_no"), rs.getString("name"), rs.getString("balance") );
					 System.out.println("+-----------------+--------------------+------------------+");
						         	
				 }
				 else {
					 System.out.println("*******************  Customer's account number does not Exist   *******************");
				 }
	         
		      }
			   catch (SQLException e) {
		         e.printStackTrace();
		      } 
		}

}
