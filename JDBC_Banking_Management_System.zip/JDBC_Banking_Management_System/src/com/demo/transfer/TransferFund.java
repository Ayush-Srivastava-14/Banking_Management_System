package com.demo.transfer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class TransferFund {


	static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	static final String USER = "root";
	static final String PASS = "";
	static final String QUERY = "UPDATE account SET balance = (balance - ?) where account_no = ?";
	static final String QUERY2 = "UPDATE account SET balance = (balance + ?) where account_no = ?";
	static final String QUERY3 = "SELECT * from account where account_no = ?";
	
		public static void TransferFunds() {
			// TODO Auto-generated method stub
	
			
			try {
					Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
					
				
					PreparedStatement stmt = conn.prepareStatement(QUERY);
		         
					PreparedStatement stmt2 = conn.prepareStatement(QUERY2);
				    
					PreparedStatement stmt3 = conn.prepareStatement(QUERY3);
				    
					PreparedStatement stmt4 = conn.prepareStatement(QUERY3);
					
					 Scanner sc = new Scanner(System.in);
					 System.out.println("Enter your Account number to Transfer Funds: ");
					 int sendAccno = sc.nextInt();
					 
					 
					 stmt3.setInt(1,sendAccno);
					 
					ResultSet rs = stmt3.executeQuery();
					
					
					//to check if sender's account number exist or not
						if((rs.next() == true)) 
						{
							 System.out.println("Enter the Receiver's Account number to Transfer Funds: ");
							 int recAccno = sc.nextInt();
							 
							//to check if receiver's account number exist or not
							 stmt4.setInt(1, recAccno);
							 ResultSet rs2 = stmt4.executeQuery();
							
							 if(rs2.next() == true)
							 {
							 //Check if balance is sufficient to transfer money

								 System.out.println("Enter the Amount to be withdrawn: ");
								 int amount = sc.nextInt();
								 
								 
								if(rs.getInt("balance") >= amount)
								{
									 //Debit funds
									 stmt.setInt(1,amount);
									 stmt.setInt(2, sendAccno);
								     
									int rows = stmt.executeUpdate();
									if(rows == 1)
									{
										
										System.out.println("****************  Amount of Rs." +amount + " Transferred successfully  ****************");  
									}
									else
									{
										System.out.println("****************  Could Not Transfer. Try again Later  ****************");
									}
								
									//Credit funds
									stmt2.setInt(1,amount);
									stmt2.setInt(2, recAccno);
								        
									int rows2 = stmt2.executeUpdate();
									if(rows2 == 1)
									{
											System.out.println("****************  Amount of Rs." +amount + " Credited successfully to Account No. "+sendAccno+"  ****************");  
									}
									else
									{
											System.out.println("****************  Could Not Transfer. Try again Later  ****************");
									}
									
									
								}
								
								else
								{
								  System.out.println("****************  Amount entered exceeds Balance  ****************");
								}
								
						}
						
						else
						{
							System.out.println("**************** Receiver's Account does not exist  ****************");
						}
							 
					}
					else
					{
						System.out.println("****************  Sender's Account does not exist  ****************");
					}
						
				}
				catch (SQLException e) {
			         e.printStackTrace();
			      } 
		}
	
}
