package com.demo.update;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class updateCustomer {


	static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	   static final String USER = "root";
	   static final String PASS = "";
	   static final String QUERY = "UPDATE account set name = ?, balance = ? where account_no = ?";
	   static final String QUERY2 = "SELECT * from account where account_no = ?";
	
	public static void updateCustomerDetails() {
		

		 // Open a connection
	      try {

	Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
	         PreparedStatement ps = conn.prepareStatement(QUERY);
	    		  PreparedStatement stmt2 = conn.prepareStatement(QUERY2);
				    
	      
	    	 Scanner sc = new Scanner(System.in);
	    	 System.out.println("Enter Customer Account Number to update details: ");
	    	 int cid = sc.nextInt();
	    	 sc.nextLine();
	    	 
	    	 stmt2.setInt(1, cid);
	    	 ResultSet rs = stmt2.executeQuery();
	    	// boolean flag =stmt2.execute();
		    	 if(rs.next()) {
		    	 
		    	 System.out.println("Enter updated Customer name");
		    	 String cname = sc.nextLine();
		    	 
		    	 System.out.println("Enter  updated Customer Balance");
		    	 int bal = sc.nextInt();
		    	 
		    	 
		    	ps.setString(1, cname);
		    	ps.setInt(2, bal);
		    	ps.setInt(3, cid);
		    	
		    	 int rows = ps.executeUpdate(); 
		    	 if(rows > 0)
		    	System.out.println("****************  " + rows + " row(s) Updated successfully  **************** ");
		    	 //conn.close();
		    	 //else
		    		// System.out.println("*******************  Customer's account number does not Exist   *******************");
					
		    	 }
		    	 else {
		    		 System.out.println("*******************  Customer's account number does not Exist   *******************");
						
		    	 }
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } 
	}

}
