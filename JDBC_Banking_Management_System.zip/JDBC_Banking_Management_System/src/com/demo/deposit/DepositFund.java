package com.demo.deposit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DepositFund {

	static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	static final String USER = "root";
	static final String PASS = "";
	static final String QUERY = "UPDATE account SET balance = (balance + ?) where account_no = ?";
	static final String QUERY2 = "SELECT * from account where account_no = ?";
	
		public static void depositFunds() {
			// TODO Auto-generated method stub
	
			
	try {
				Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				
			
				PreparedStatement stmt = conn.prepareStatement(QUERY);
				PreparedStatement stmt2 = conn.prepareStatement(QUERY2);
			    
				 Scanner sc = new Scanner(System.in);
				 System.out.println("Enter the Customer account number: ");
				 int accno = sc.nextInt();
				 
				 stmt2.setInt(1,accno);	
				ResultSet rs = stmt2.executeQuery();
				
				//if accno exists
				if(rs.next()== true)
				{	
					 System.out.println("Enter the Amount to be deposited: ");
					 int cbal = sc.nextInt();
					 
					 
					 
					 stmt.setInt(1,cbal);				
					stmt.setInt(2,accno);	
					int rows = stmt.executeUpdate();
					if(rows == 1)
					{
						System.out.println("**************** Amount of Rs." +cbal + " Deposited successfully  ****************");  
					}
					else
					{
						System.out.println("****************  Could not deposit. Try again Later  ****************");
					}
				}
				else {
					System.out.println("*******************  Customer's account number does not Exist   *******************");
					
				}
					
		      }
			   catch (SQLException e) {
		         e.printStackTrace();
		      } 
		}
	
}
