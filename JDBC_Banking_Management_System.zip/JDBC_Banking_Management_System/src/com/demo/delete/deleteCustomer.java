package com.demo.delete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class deleteCustomer {


	static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	   static final String USER = "root";
	   static final String PASS = "";
	   static final String QUERY = "DELETE from account where account_no = ?";

	
	public static void deleteCustomerDetails() {
		 // Open a connection
	      try(

	Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
	         PreparedStatement ps = conn.prepareStatement(QUERY);)
	      {
	    	 Scanner sc = new Scanner(System.in);
	    	 System.out.println("Enter Customer Account Number to Delete: ");
	    	 int cid = sc.nextInt();
	    	 sc.nextLine();
	    	 
	    	 
	    	ps.setInt(1, cid);
	    	
	    	 int rows = ps.executeUpdate();
	    	 if(rows !=0 ) {
	    	System.out.println(rows+ " row(s) deleted successfully...........");
	    	 }
	    	 else {
	    		 System.out.println("*******************  Customer's account number does not Exist   *******************");
					
	    	 }
	      
	         
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } 
	}

}
