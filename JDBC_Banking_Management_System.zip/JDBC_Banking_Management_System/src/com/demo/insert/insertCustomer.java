package com.demo.insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class insertCustomer {


	static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	   static final String USER = "root";
	   static final String PASS = "";
	   static final String QUERY = "INSERT into account(account_no, name, balance) values(?,?,?)";
	   static final String QUERY2 = "select * from account where account_no = ?";

	   
	public static void insertCustomerDetails() {

		      // Open a connection
		      try {

		Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
		         PreparedStatement ps = conn.prepareStatement(QUERY);
		    	 
		    	 PreparedStatement ps2 = conn.prepareStatement(QUERY2);
				    	 
		    	  Scanner sc = new Scanner(System.in);
		    	 System.out.println("Enter Customer account no. ");
		    	 int cid = sc.nextInt();
		    	 sc.nextLine();
		    	 
		    	 ps2.setInt(1, cid);
		    	 ResultSet rs = ps2.executeQuery();
			     if(!(rs.next()))
			     {
			    	 System.out.println("Enter Customer name");
			    	 String cname = sc.nextLine();
			    	 
			    	 System.out.println("Enter Customer balance");
			    	 int bal = sc.nextInt();
			    	 
			    	 
			    	ps.setInt(1, cid);
			    	ps.setString(2, cname);
			    	ps.setInt(3, bal);
			    	int rowsAffected = ps.executeUpdate(); 
			    	System.out.println("****************  " + rowsAffected + " row(s )Inserted successfully  **************** \n");
			    	 conn.close();
			      
			    }
			     else {
			    	 System.out.println(" ************************ Customer Account already exists  ************************\n");
			     }
		      } catch (SQLException e) {
		         e.printStackTrace();
		      } 
		   }

	}