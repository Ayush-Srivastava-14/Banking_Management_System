package com.demo.display;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class displayCustomer {

	
	   static final String DB_URL = "jdbc:mysql://localhost:3306/bank_jdbc_amdocs";
	   static final String USER = "root";
	   static final String PASS = "";
	   static final String QUERY = "SELECT * from account";

		public static void displayCustomerDetails() {
			// TODO Auto-generated method stub
	
			 try {
	
				Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				//Scanner sc = new Scanner(System.in);
			
			
				Statement stmt = conn.createStatement();
	           
			    ResultSet rs = stmt.executeQuery(QUERY);
				
				// System.out.println("Inside display fn");
	         // Extract data from result set
				 System.out.println("****************************************************************");
				 System.out.println("+-----------------+--------------------+------------------+");
				 System.out.println("| Account Number  | Customer Name      | Balance (INR)    |");
				 while (rs.next()) {
	            // Retrieve by column name
	            	
					 
					 System.out.println("+-----------------+--------------------+------------------+");
					 System.out.printf("|  %-13s  | %-17s  | %-15s  |\n", rs.getInt("account_no"), rs.getString("name"), rs.getString("balance") );
					 System.out.println("+-----------------+--------------------+------------------+");
					 
					/* 
		            System.out.print("Account Number: " + rs.getInt("account_no")+"\t | ");
		            System.out.print(" Customer Name: " + rs.getString("name")+"\t\t\t | ");
		            System.out.println(" Balance: " + rs.getString("balance")+"\t | ");
					*/
					 
					
	         	
				 }
				 System.out.println();
				 System.out.println("****************************************************************");
				 conn.close();
		      }
			   catch (SQLException e) {
		         e.printStackTrace();
		      } 
		}

}
